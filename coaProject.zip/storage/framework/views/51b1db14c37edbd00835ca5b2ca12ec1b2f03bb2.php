<div class="table-responsive">
    <table class="table" id="products-table">
        <thead>
        <tr>
        <th nowrap>產品名稱</th>
        <th>特色</th>
        <th nowrap>出品單位</th>
        <!-- <th>Spec And Price</th> -->
        <th nowrap>觀看次數</th>
        <th colspan="3">動作</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td ><?php echo $product->name; ?></td>
            <td><?php echo e(str_limit($product->feature,150,'...')); ?></td>
            <td><?php echo $product->produce_org; ?></td>
            <!-- <td><?php echo $product->spec_and_price; ?></td> -->
            <td><?php echo $product->view_count; ?></td>
                <td>

                    <div class='btn-group'>
                        <a href="<?php echo route('products.show', [$product->id]); ?>" class='btn btn-default '><i class="fas fa-eye"></i></a>
            <?php if(Auth::user()->role == 1 || Auth::user()->id == $product->user_id): ?>
                        <a href="<?php echo route('products.edit', [$product->id]); ?>" class='btn btn-default '><i class="fas fa-edit"></i></a>
            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger btn-xs pull-left" style="margin-left: 6px" onclick="var result = confirm('Are you sure you wish to delete this product?');">
                        <i class="fas fa-trash-alt"></i>
                    </button>
            </form>
            <?php endif; ?>
                    </div>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php echo e($products->links()); ?>

</div>
<?php /**PATH D:\xampp\htdocs\coaProject\resources\views/products/table.blade.php ENDPATH**/ ?>