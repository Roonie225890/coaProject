<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="content">
      <div class="card mb-3">
          <img src="<?php echo e($product->img); ?>" class="card-img-top" alt="...">
          <div class="card-body">
              <h1 class="card-title"><strong><?php echo e($product->name); ?></strong></h1>
              <h3 class="card-text"><strong><?php echo e($product->produce_org); ?></strong></h3>
              <h4 class="card-text"><?php echo e($product->feature); ?></h4>
              <p class="card-text"><?php echo e($product->spec_and_price); ?></p>
              <p class="card-text"><?php echo e($product->sale_place); ?></p>
              <p class="card-text"><?php echo e($product->contact_tel); ?></p>
          </div>
      </div>

      <?php echo $__env->make('layouts.comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="row ">
      <div class="col-md-12 col-sm-12  col-xs-12 col-lg-12">
      <div class="card border-primary mb-3">
            <form method="post" action="<?php echo e(route('comments.store')); ?>">
                <?php echo csrf_field(); ?>
              <input type="hidden" name="commentable_type" value="App\Product">
              <input type="hidden" name="commentable_id" value="<?php echo e($product->id); ?>">

              <div class="form-group">
                    <div class="card-header bg-primary"><strong>Comments</strong></div>
                    <div class="card-body text-secondary">
                  <textarea placeholder="Enter comment"
                            style="resize: vertical"
                            id="body"
                            name="body"
                            rows="3" spellcheck="false"
                            class="form-control autosize-target text-left">
                  </textarea>
              </div>
              </div>
              <div class="form-group">
                  <input type="submit" class="btn btn-primary col-md-1 offset-md-10" value="Submit"/>
              </div>
            </form>
      </div>
      </div>
      </div>

                <div class="row" style="padding-left: 20px">
                    <a href="<?php echo route('products.index'); ?>" class="btn btn-default col-md-1"><strong>Back</strong></a>
                </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dataCOA\resources\views/products/show.blade.php ENDPATH**/ ?>