<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $product->id; ?></p>
</div>

<!-- User Id Field -->
<div class="form-group">
    <?php echo Form::label('user_id', 'User Id:'); ?>

    <p><?php echo $product->user_id; ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo $product->name; ?></p>
</div>

<!-- Feature Field -->
<div class="form-group">
    <?php echo Form::label('feature', 'Feature:'); ?>

    <p><?php echo $product->feature; ?></p>
</div>

<!-- Sale Place Field -->
<div class="form-group">
    <?php echo Form::label('sale_place', 'Sale Place:'); ?>

    <p><?php echo $product->sale_place; ?></p>
</div>

<!-- Produce Org Field -->
<div class="form-group">
    <?php echo Form::label('produce_org', 'Produce Org:'); ?>

    <p><?php echo $product->produce_org; ?></p>
</div>

<!-- Spec And Price Field -->
<div class="form-group">
    <?php echo Form::label('spec_and_price', 'Spec And Price:'); ?>

    <p><?php echo $product->spec_and_price; ?></p>
</div>

<!-- Contact Tel Field -->
<div class="form-group">
    <?php echo Form::label('contact_tel', 'Contact Tel:'); ?>

    <p><?php echo $product->contact_tel; ?></p>
</div>

<!-- Img Field -->
<div class="form-group">
    <?php echo Form::label('img', 'Img:'); ?>

    <p><?php echo $product->img; ?></p>
</div>

<!-- View Count Field -->
<div class="form-group">
    <?php echo Form::label('view_count', 'View Count:'); ?>

    <p><?php echo $product->view_count; ?></p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    <?php echo Form::label('deleted_at', 'Deleted At:'); ?>

    <p><?php echo $product->deleted_at; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $product->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $product->updated_at; ?></p>
</div>

<?php /**PATH D:\xampp\htdocs\dataCOA\resources\views/products/show_fields.blade.php ENDPATH**/ ?>