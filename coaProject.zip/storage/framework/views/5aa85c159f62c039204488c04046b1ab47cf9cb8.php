
 <div class="row">
		<div class="col-md-12 col-sm-12  col-xs-12 col-lg-12">

            <!-- Fluid width widget -->
            <div class="card border-primary mb-3" >
                <div class="card-header bg-primary"><strong>Recent Comments</strong></div>
                <div class="card-body text-secondary">
                  <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="media">

                          <div class="media-body">
                              <h4 class="media-heading">
                                  <small><a> <?php echo e($comment->user->name); ?></a>   -  <?php echo e($comment->user->email); ?></small>
                              </h4>
                              <br>
                              <p><?php echo e($comment->body); ?></p>
                              <small class="text-muted">  commented on <?php echo e($comment->created_at); ?></small>
                              <div class="card-footer bg-transparent border-success"></div>
                          </div>
                      </li>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <!-- <h5 class="card-title">Secondary card title</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> -->
                </div>
            </div>

            <!-- End fluid width widget -->

		</div>
	</div>
<?php /**PATH D:\xampp\htdocs\dataCOA\resources\views/layouts/comments.blade.php ENDPATH**/ ?>